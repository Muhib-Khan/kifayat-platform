const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  
  const consoleErrors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') {
      consoleErrors.push(msg.text());
    }
  });
  
  page.on('pageerror', err => {
    consoleErrors.push('PAGE ERROR: ' + err.message);
  });
  
  try {
    // Login
    await page.goto('http://localhost:5000/auth', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(2000);
    
    await page.fill('input[type="email"]', 'testadmin@kifayat.co');
    await page.fill('input[type="password"]', 'test123456');
    await page.click('button[type="submit"]');
    await page.waitForTimeout(3000);
    
    // Navigate to admin
    await page.goto('http://localhost:5000/admin', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(5000);
    
    const title = await page.title();
    const visible = await page.evaluate(() => document.body.innerText);
    const screenshot = await page.screenshot({ fullPage: true });
    
    console.log('Page title:', title);
    console.log('Body text length:', visible.length);
    console.log('Body text preview:', visible.substring(0, 1500));
    console.log('---');
    console.log('Console errors:', consoleErrors.length);
    consoleErrors.forEach(e => console.log('  ERROR:', e));
    
    const fs = require('fs');
    fs.writeFileSync('C:/Users/Admin/AppData/Local/Temp/kilo/admin-screenshot.png', screenshot);
    console.log('Screenshot saved');
  } catch (e) {
    console.log('Navigation error:', e.message);
  }
  
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
